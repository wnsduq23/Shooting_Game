#ifndef MAIN_H
# define MAIN_H

extern int g_scene;

#define TITLE		0
#define LOAD		1
#define INGAME		2
#define CLEAR		3
#define GAMEOVER	4

#endif
